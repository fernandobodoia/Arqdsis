insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Domingo', 1, 22, 38, 'moderate rain');
insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Segunda-feira', 2, 15, 40, 'light rain');
insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Terça-feira', 3, 11, 35, 'moderate rain');
insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Quarta-feira', 4, 14, 33, 'heavy intensity rain');
insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Quinta-feira', 5, 17, 24, 'ligth rain');
insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Sexta-feira', 6, 23, 60, 'moderate rain');
insert into previsaodotempo (diaSemana, tempMin, tempMax, umi, descricao, data_hora, latitude, longitude) values ('Sábado', 7, 28, 90, 'moderate rain');

insert into usuario (id, usuario, senha) values (1, 'admin', 'admin');