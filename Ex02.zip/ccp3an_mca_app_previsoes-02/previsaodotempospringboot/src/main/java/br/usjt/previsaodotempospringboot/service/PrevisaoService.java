package br.usjt.previsaodotempospringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.usjt.previsaodotempospringboot.model.Previsao;
import br.usjt.previsaodotempospringboot.repository.PrevisaoRepository;

@Service
public class PrevisaoService {

	@Autowired
	private PrevisaoRepository respoRepository;
	
	public void salvar(Previsao previsao) {
		respoRepository.save(previsao);
	}
	
	public List<Previsao> listarTodos() {
		List<Previsao> previsoes = respoRepository.findAll();
		return previsoes;
	}
	
	
}
