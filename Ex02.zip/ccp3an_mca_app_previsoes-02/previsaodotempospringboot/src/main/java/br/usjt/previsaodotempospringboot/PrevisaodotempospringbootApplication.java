package br.usjt.previsaodotempospringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrevisaodotempospringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrevisaodotempospringbootApplication.class, args);
	}

}
