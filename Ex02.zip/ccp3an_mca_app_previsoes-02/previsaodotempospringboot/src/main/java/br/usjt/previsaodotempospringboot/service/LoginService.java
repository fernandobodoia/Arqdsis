package br.usjt.previsaodotempospringboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.usjt.previsaodotempospringboot.model.Usuario;
import br.usjt.previsaodotempospringboot.repository.UsuarioRepository;

@Service
public class LoginService {
	
	@Autowired
	private UsuarioRepository respo;
	
	public boolean logar(Usuario usuario) {
		return respo.findOneByUsuarioAndSenha(usuario.getUsuario(), usuario.getSenha()) != null;
	}
}
	