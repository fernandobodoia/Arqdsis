package br.usjt.persistence;

import br.usjt.util.JPAUtil;

public class InsereDia {

	public static void main(String[] args) {
		EntityManager manager = JPAUtil.getEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		//iniciar a transação
		transaction.begin();
		Dia u = new Dia0();
		u.setNome("Segunda");

		//Persistir o banco no obj usuario
		manager.persist(u);
		transaction.commit();
		
		//finaliza a transação
		manager.close();
		JPAUtil.close();
	}
}