package br.usjt.ExercicioAula01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioAula01Application {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioAula01Application.class, args);
	}

}
